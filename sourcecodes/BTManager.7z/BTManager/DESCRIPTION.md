BTManager+ brings powerful management features to your bluetooth devices.
### Features:
- Rename any bluetooth device
- Display a confirm alert when switching to the audio route to a specific device
- Blocking a device from connecting automatically (BETA)
- Configure a default device and priority list for each application
- Activator events for Audio Routes
- More Coming Soon

### Depends:
- PreferenceLoader
- libSparkAppList
- Activator (optional, but required for Activator-related features)
### Support:
Feel free to reach out to me for help or post an issue on the project [GitHub](https://github.com/BeckettOBrien/BTManager)